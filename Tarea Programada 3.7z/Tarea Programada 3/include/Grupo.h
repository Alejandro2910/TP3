#ifndef GRUPO_H
#define GRUPO_H
#include <list>
#include "Miembro.h"
#include <sstream>

using namespace std;

class Grupo
{
    public:
        Grupo();
        virtual ~Grupo();
        void guardeMiembro(Miembro*);
        string muestreGrupo();

    protected:
        list<Miembro*> grupoDeTrabajo;
    private:
};

#endif // GRUPO_H
