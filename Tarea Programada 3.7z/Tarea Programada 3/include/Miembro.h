#ifndef MIEMBRO_H
#define MIEMBRO_H
#include "Tarea.h"
#include <list>
#include <sstream>

using namespace std;

class Miembro
{
    public:
        Miembro();
        virtual ~Miembro();
        void setNombreMiembro(string);
        string getNombreMiembro();
        string getDatosMiembro();


    protected:
        string nombreMiembro;
        list<Tarea*> tareasPorRealizar;
    private:
};

#endif // MIEMBRO_H
