#ifndef TAREA_H
#define TAREA_H
#include <iostream>
#include <sstream>

using namespace std;

class Tarea
{
    public:
        Tarea();
        virtual ~Tarea();
        void setTarea(string, int , float);
        int getPrioridad();
        string getDatos();
        void setNombre(string);
        void setPrioridad(int);
        void setEsf(float);
        string getNombre();
        float getEsf();

    protected:
        string nombre;
        string personaAsociada;
        int prioridad;
        float esfuerzoEstimado;
    private:
};

#endif // TAREA_H
