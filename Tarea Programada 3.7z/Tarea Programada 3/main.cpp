#include <iostream>
#include "Software.h"
#include "Grupo.h"
#include "Miembro.h"

using namespace std;

int main()
{
    int resp=1;
    string n;
    int resp2=0;
    cout << "Bienvenido, establezca el nombre del software a trabajar: " << endl;
    cin>>n;
    Software *s=new Software(n);
    Grupo *g=new Grupo();
    while(resp!=0){
            cout<<"Que desea hacer?\n1. Agregar requerimento\n2. Muestre requerimentos\n3. Modifique requerimentos\n4. Borre\n5. Agregue miembro\n6. Muestre grupo\n0. Terminar "<<endl;
            cin>>resp;
        if(resp!=0){
            switch(resp){
            case 1:
                {
                s->agregueRequerimento();
                }
                break;
            case 2:
                {
                cout<<s->muestreRequerimentos()<<endl;
                }
                break;
            case 3:
                {
                cout<<"Que desea modificar?\n1. Modificar nombre.  \n2. Modificar tipo. \n3. Agregar tarea."<<endl;
                cin>>resp2;
                s->modifiqueRequerimento(resp2);
                }
                break;
            case 4:
                {
                cout<<"Que desea borrar?\n1. Borrar requerimentos\n2. Borrar tarea"<<endl;
                cin>>resp2;
                s->borre(resp2);
                }
                break;
            case 5:
                {
                string nom="";
                cout<<"Nombre del miembro a agregar: "<<endl;
                cin>>nom;
                Miembro *m=new Miembro();
                m->setNombreMiembro(nom);
                g->guardeMiembro(m);
                }
                break;
            case 6:
                {
                cout<<g->muestreGrupo()<<endl;
                }
                break;
            }
        }
    }
    delete s;
    return 0;
}
