#include "Miembro.h"

Miembro::Miembro()
{
    //ctor
}

Miembro::~Miembro()
{
    //dtor
}

void Miembro::setNombreMiembro(string n){
    nombreMiembro=n;
}

string Miembro::getNombreMiembro(){
    return nombreMiembro;
}

string Miembro::getDatosMiembro(){
    stringstream datos;
    datos<<"Nombre: "<<nombreMiembro<<"\nTareas asociadas: "<<endl;
    list<Tarea*>::iterator it;
    for(it=tareasPorRealizar.begin();it!=tareasPorRealizar.end();it++){
        datos<<"Nombre: "<<(*it)->getNombre()<<"  Prioridad: "<<(*it)->getPrioridad()<<"  Esfuerzo estimado: "<<(*it)->getEsf()<<endl;
    }
    return datos.str();
}
